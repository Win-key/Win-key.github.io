package com.winkey.poi.word;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FindField {

	
	public static void main(String[] args) {
		
		//making current project directory(src) as input
		String dir = "src";
		String keyWord = "document";
		LoopThroghDir(new File(dir),  keyWord);
		
	}
	
	public static void readFile(File file, String keyWord) {
		
		try {
			FileInputStream in = new FileInputStream(file);
			Scanner scan = new Scanner(in);
			int count = 0;
		
			while (scan.hasNext()) {
				//if the word contains the keyword increase the count by 1
				if (scan.next().contains(keyWord))
					count++;
			}
			System.out.println(count + " occurrences are there in " + file.getName() + " for " + keyWord);
			scan.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void LoopThroghDir(File node, String keyWord){

	//read the file if node.isFile() == true
	if(node.isFile()){
		readFile(node, keyWord);
	}
	
	//read the file if node.isDirectory() == true
	if(node.isDirectory()){
		//make a entry of all files in the dir
		String[] subNote = node.list();
		for(String filename : subNote){
			//logic to loop through all the files
			LoopThroghDir(new File(node, filename), keyWord);
		}
	}
 
    }
	
	
}
