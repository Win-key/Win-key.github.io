package com.winkey.poi.word;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRelation;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHyperlink;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;

public class CreateTable {

   public static void main(String[] args)throws Exception {

      //Blank Document
      XWPFDocument document = new XWPFDocument();
        
      //Write the Document in file system
      FileOutputStream out = new FileOutputStream(new File("testFolder\\create_table.docx"));
        
      //create table
      XWPFTable table = document.createTable();
		
      //create first row
      XWPFTableRow tableRowOne = table.getRow(0);
      tableRowOne.getCell(0).setText("col one, row one");
      tableRowOne.addNewTableCell().setText("col two, row one");
      tableRowOne.addNewTableCell().setText("col three, row one");
		
      //create second row
      XWPFTableRow tableRowTwo = table.createRow();
      tableRowTwo.getCell(0).setText("col one, row two");
      tableRowTwo.getCell(1).setText("col two, row two");
      tableRowTwo.getCell(2).setText("col three, row two");
      
      //create third row
      XWPFTableRow tableRowThree = table.createRow();
      tableRowThree.getCell(0).setText("col one, row three");
      tableRowThree.getCell(1).setText("col two, row three");
      XWPFParagraph paragraph = tableRowThree.getCell(2).addParagraph();
      
      String id= document.getPackagePart().addExternalRelationship("text.txt", XWPFRelation.HYPERLINK.getRelation()).getId();

      //Append the link and bind it to the relationship
       CTHyperlink cLink =  paragraph.getCTP().addNewHyperlink();//getCTP().addNewHyperlink();
      cLink.setId(id);

      //Create the linked text
      CTText ctText=CTText.Factory.newInstance();
      ctText.setStringValue("link to text.txt");
      CTR ctr=CTR.Factory.newInstance();
      ctr.setTArray(new CTText[]{ctText});

      //Insert the linked text into the link
      cLink.setRArray(new CTR[]{ctr});
      
      document.write(out);
      out.close();
      document.close();
      
      System.out.println("create_table.docx written successully");
   }
}